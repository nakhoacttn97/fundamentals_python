print(round(123.45678)) # 123 (trả về số nguyên nếu bỏ qua tham số ndigits)
print(round(123.45678,1)) # 123.5
print(round(123.45678,2)) # 123.46
print(round(123.65678,0)) # 124.0
print(round(123.45678,-1)) # 120
print(round(126.45678,-1)) # 130