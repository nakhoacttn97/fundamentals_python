import calendar

print(calendar.monthrange(2021, 10))