import my_lib

a = int(input("Nhập a = "))
b = int(input("Nhập b = "))
my_lib.In_Tong(a, b)
