def Tinh_Tong(a, b):
    return a+b


def In_Tong(a, b):
    tong = Tinh_Tong(a, b)
    print("Tổng %i + %i = %i" % (a, b, tong))

