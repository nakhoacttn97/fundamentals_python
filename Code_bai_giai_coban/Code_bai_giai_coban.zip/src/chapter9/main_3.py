from my_lib import *

# main
a = int(input("so thu nhat: "))
b = int(input("so thu hai: "))
In_Tong(a,b)
tong = Tinh_Tong(a,b)
print("Ket qua la: ",tong)