from my_lib import In_Tong

a = int(input("Nhập a = "))
b = int(input("Nhập b = "))
In_Tong(a, b)
