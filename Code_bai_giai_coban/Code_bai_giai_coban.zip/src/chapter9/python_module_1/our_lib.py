def f5():
    print("our lib: f5")
def f6():
    print("our lib: f6")    