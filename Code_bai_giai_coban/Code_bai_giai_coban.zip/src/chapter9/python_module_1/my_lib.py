def f3():
    print("my lib: f3")
def f4():
    print("my lib: f4")    
x=3
y=5    