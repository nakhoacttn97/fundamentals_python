'''
Created on Feb 2, 2017

@author: KTPHUONG
'''
# doi nhiet do tu do C sang do F
C = eval(input('Nhập độ C:\n'))
F = 9/5 * C + 32
print('%.2f độ C = %.2f độ F'%(C,F))
