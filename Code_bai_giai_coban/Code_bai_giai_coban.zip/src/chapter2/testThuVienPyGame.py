'''
Created on Dec 28, 2016

@author: KTPHUONG
Thu vien download pygame http://www.lfd.uci.edu/~gohlke/pythonlibs/#pygame
can phai test phien ban truoc khi down de chon cho dung bang lenh
import pip
print(pip.pep425tags.get_supported())

goi y xem cac game http://www.pygame.org/tags/pygame

C:\Users\KTPHUONG\AppData\Local\Programs\Python\Python35-32\Scripts

'''
import pygame
import pygame.examples.aliens as game
game.main()