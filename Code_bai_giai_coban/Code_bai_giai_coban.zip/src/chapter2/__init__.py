"""
" author: Phuong Khuat
" version: 1.0
" date: 03 Jan 2017
"
"""
"""
number = 100            # integer 
average = 8.5           # floating point
name = "Thuy Phuong"    # string

print(number)
print(average)
print(name)

x = 0x25
print (x)




greeting = "Hello Python"
print (greeting)
print (greeting[0])
print (greeting[2:5])
print (greeting[3:])

name = "Thuy Phuong"
age = 25
height = 1.60
weight = 52.5
print ("My name is %s. I'm %i years old. My height is %f m and weight is %f kg" % (name, age, height, weight))


name = input("What's your name?")
print ("My name's", name)


age = eval(input("How old are you?"))
print ("I'm %i years old." % (age))       


strInt = "12"
print(int(strInt)*2)
rl = 25
em = 3
complexNum = complex(rl,em)
print(complexNum)
numEval = eval(strInt)
print(numEval + numEval)

"""
print (chr(98))
print ()
