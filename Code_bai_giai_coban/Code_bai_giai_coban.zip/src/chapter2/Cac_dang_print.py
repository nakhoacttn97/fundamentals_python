# # dạng 1
# print("Hello"+" the World.")
# name = "Alice"
# print("Hello "+name+".")
# age = 21
# print("My name is "+name+". I am "+str(age)+" years old.")

# dạng 2
print("\n")
print("Hello", "the World.")
name = "Alice"
print("Hello", name, ".")
age = 21
print("My name is", name, ". I am", age, "years old.")

# dạng 3
print("\n")
name = "Alice"
print("Hello %s" % (name))
age = 21
print("My name is %s. I am %d years old." % (name, age))
