# toan = input("Điểm môn toán: ")
# van = input("Điểm môn văn: ")
# trung_binh = (toan+van)/2

# toan = float(input("Điểm môn toán: "))
# van = float(input("Điểm môn văn: "))
# trung_binh = (toan+van)/2

toan = eval(input("Điểm môn toán: "))
van = eval(input("Điểm môn văn: "))
trung_binh = (toan+van)/2