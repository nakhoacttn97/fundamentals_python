'''
Created on Dec 27, 2016

@author: KTPHUONG
'''
x = eval(input("Nhập x:"))
y = eval(input("Nhập y:"))
tong = x+y
hieu = x-y
tich = x*y
thuong = x/y
print("Tổng = %d, hiệu = %d, tích = %d, thương = %.1f"%(tong, hieu, tich, thuong))

