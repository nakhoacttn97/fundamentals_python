# xu ly chuoi
s1 = input('Nhập chuỗi s1:\n')
s2 = input('Nhập chuỗi s2:\n')
s3 = input('Nhập chuỗi s3:\n')
index = int(input('Nhập index:\n'))
print("Chiều dài chuỗi s1 =", len(s1))
print("Chiều dài chuỗi s2 =", len(s2))
print("Chiều dài chuỗi s3 =", len(s3))
s4 = s1[index:]
print("Chuỗi s4 =", s4)
print("Chuỗi s2 lặp lại 2 lần =", s2*2)


