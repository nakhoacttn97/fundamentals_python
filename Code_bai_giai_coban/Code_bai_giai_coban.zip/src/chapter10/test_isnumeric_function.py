chuoi_so = input("Bạn nhập một số: ")
la_so = chuoi_so.isdecimal()
print(la_so)
la_so = chuoi_so.isnumeric()
print(la_so)

