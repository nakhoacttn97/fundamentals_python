
# ages = []
# ages.append(23)
# ages.append(21)
# ages.append(27)
# ages.append(25)
# print(ages)

# fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
# newlist = [x.upper() for x in fruits]
# print(newlist)

# print()

# fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
# newlist = [x for x in fruits if "a" in x]
# print(newlist)

# print()

# newlist = [x for x in fruits if x != "apple"]
# print(newlist)

# print()

# fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
# newlist = [x if x != "banana" else "orange" for x in fruits]
# print(newlist)

chuoi = "spring,summer,fall,winter"
lst = chuoi.split(",")
print(lst)

