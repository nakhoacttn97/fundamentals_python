print("CT giả lập thực đơn.")
tiep_tuc = True
while tiep_tuc:
    print("Thực đơn".center(30, " "))
    print("* "*15)
    print("1. Nhập hai số nguyên a và b.")
    print("2. Tính tổng a + b.")
    print("3. Tính hiệu a - b.")
    print("4. Thoát.")
    print("* "*15)
    chon = int(input("Mời bạn chọn: "))
    if chon == 1:
        pass
    elif chon == 2:
        pass
    elif chon == 3:
        pass
    elif chon == 4:
        tiep_tuc = False
    else:
        pass
