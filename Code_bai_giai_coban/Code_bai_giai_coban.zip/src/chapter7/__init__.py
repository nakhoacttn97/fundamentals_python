print('hello')
for i in 'happy new year':
    print(i)