
tup1 = (12,24,21,25,36,32)
print(tup1)
print(type(tup1))
print()

tup2 = 16, 24, 23, 35, 27, 21
print(tup2)
print(type(tup2))
print()

tup3 = (24,)
print(tup3)
print(type(tup3))

