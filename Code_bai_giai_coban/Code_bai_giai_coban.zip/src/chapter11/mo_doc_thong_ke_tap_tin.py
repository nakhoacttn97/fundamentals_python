'''
Created on Feb 6, 2017

@author: KTPHUONG
'''
import xu_ly_tap_tin
filename = input('Nhập tên tập tin:\n')
xu_ly_tap_tin.read_report_file(filename)