import tinh_toan

a = 23
b = 34
tong = tinh_toan.Tinh_tong(a,b)
print("Tong: ", tong)
hieu = tinh_toan.Tinh_hieu(a,b)
print("Hieu: ", hieu)    