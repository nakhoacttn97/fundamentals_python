def Tinh_tong(a,b):
    return a + b

def Tinh_hieu(a,b):
    return a - b