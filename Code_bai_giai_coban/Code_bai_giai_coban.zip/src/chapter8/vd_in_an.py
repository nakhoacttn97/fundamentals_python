print("Le Thi Bach".ljust(30," ")+"Tuyet")
print("Nguyen Van".ljust(30," ")+"Tam")
print("Cong Tang Ton Nu Ha Thi Bach".ljust(30," ")+"Lan")