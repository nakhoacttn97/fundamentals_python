# # biểu thức hàm không tên
# def ham_cong(x, y): return x+y


# def main():
#     a = 12
#     b = 34
#     t = ham_cong(a, b)
#     print("t =", t)

#     def ham_tru(x, y): return x-y
#     t = ham_tru(a, b)
#     print("t =", t)


# main()

import math

def f(x, n):
    return math.pow(math.pow(x, 2) + 1, n)

print(f(2, 3)) # in ra 125.0

