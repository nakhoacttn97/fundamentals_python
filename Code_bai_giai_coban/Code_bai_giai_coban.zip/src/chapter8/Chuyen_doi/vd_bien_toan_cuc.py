def in_s():
    global s
    s = "def"
    print(s)

s = "abc"    
print(s)
in_s()
print(s)
