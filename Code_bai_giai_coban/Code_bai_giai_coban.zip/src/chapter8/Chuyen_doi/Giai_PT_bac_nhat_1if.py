a = -2
b = 9
if a != 0:
    x = -b/a
    print("Nghiệm x =", x)
elif b == 0:
    print("PT có vô số nghiệm.")
else:
    print("PT vô nghiệm.")
