# import module tinh_bmi
import tinh_bmi
from chapter2.tinhtoan2so import tong,hieu
# call function in module tinh_bmi
tinh_bmi.tinh_bmi(52, 1.62)

all_names = dir(tinh_bmi)
print(all_names)

print('hello')
