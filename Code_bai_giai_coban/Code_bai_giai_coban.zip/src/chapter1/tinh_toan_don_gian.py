# print ("Hello world!")

x, y = 10, 5
print ('x =', x, ', y =', y)
print ("Tổng x+y =", x + y)
print ("Hiệu x-y =", x - y)
print ("Tích x*y =", x * y)
print ("Thương x/y =", x / y)
