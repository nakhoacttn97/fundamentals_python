'''
Created on Feb 2, 2017

@author: KTPHUONG
'''

if __name__ == '__main__':
    pass

# xuat ra man hinh chu HELLO
print('**    **  ******  **      **      ******')
print('**    **  **      **      **      **  **')
print('********  ******  **      **      **  **')
print('**    **  **      **      **      **  **')
print('**    **  ******  ******  ******  ******')
