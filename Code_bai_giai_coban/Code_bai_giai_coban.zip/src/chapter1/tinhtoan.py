'''
Created on Dec 22, 2016

@author: KTPHUONG
'''

if __name__ == '__main__':
    pass

x = eval(input("Nhập số:"))
print ("x * x = ", x*x )