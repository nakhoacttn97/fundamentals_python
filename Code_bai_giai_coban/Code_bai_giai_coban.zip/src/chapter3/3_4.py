'''
Created on Feb 2, 2017

@author: KTPHUONG
'''
x = 10
y = 4
print('x = %d, y = %d'%(x,y))
equivelence = x==y
print('x==y is', equivelence)
equivelence = x!=y
print('x!=y is', equivelence)
equivelence = x>y
print('x>y is', equivelence)
x = 8
y = 9
print('x = %d, y = %d'%(x,y))
equivelence = x>=y
print('x>=y is', equivelence)
equivelence = x<y
print('x<y is', equivelence)
equivelence = x<=y
print('x<=y is', equivelence)

