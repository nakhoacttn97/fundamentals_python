'''
Created on Feb 2, 2017

@author: KTPHUONG
'''
# tinh gia tri 
result = 1 + 2
print('result =', result)
original_result = result
result = result - 1
print('result =', result)
original_result = result
result = result * 2
original_result = result
print('result =', result)
result = result ** 3
original_result = result
print('result =', result)
result = result + 8
original_result = result
print('result =', result)
result = result % 7
original_result = result
print('result =', result)
result = result // 2
original_result = result
print('result =', result)

