'''
Created on Feb 2, 2017

@author: KTPHUONG
'''
x = 15
y = 12
print('Binary of x =', bin(x), ', Binary of y =', bin(y))
print('x & y =', bin(x & y))
print('x | y =', bin(x | y))
print('x ^ y =', bin(x ^ y))
print('~x =', bin(~x))
print('x << 2 =', bin(x << 2))
print('y >> 2 =', bin(y >> 2))

