'''
Created on Feb 2, 2017

@author: KTPHUONG
'''
x = True
y = False
print('x and y :',x and y)
print('x or y :',x or y)
print('not x :',not x)
print('x is y :', x is y)
print('x is not y :', x is not y)
