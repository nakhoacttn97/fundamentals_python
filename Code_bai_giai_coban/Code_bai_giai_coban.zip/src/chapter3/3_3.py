'''
Created on Feb 2, 2017

@author: KTPHUONG
'''
result = 5
print('result =', result)
result -= 1
print('result =', result)
result += 3
print('result =', result)
result = - result
print('result =', result)
result = True
print('not result =', not result)


