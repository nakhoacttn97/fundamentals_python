print("CT in các số nguyên từ 1 đến 10")
i = 1
while i <= 10:
    print("i =", i)
    i += 1

for i in range(1, 10+1):
    print("i =", i)
