print("CT in bảng cửu chương 3")
i = 1
while i <= 10:
    print("3 x", i, "=", 3*i)
    i += 1
