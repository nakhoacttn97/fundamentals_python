'''
Created on Feb 9, 2017

@author: KTPHUONG
'''
# S = (x^2 + 1)^n

n = int(input('Nhập n:\n'))
x = eval(input('Nhập x:\n'))
if n==0:
    S = 1
else:
    S = 1
    for i in range(0,n):
        S = S * (x * x + 1)
    #   print(S)
print('S = (x*x + 1)^n=', S) 