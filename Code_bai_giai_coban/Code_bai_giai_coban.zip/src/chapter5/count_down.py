'''
Created on Feb 9, 2017

@author: KTPHUONG
'''
# count down from n to 0
n = int(input('Input number:\n'))
i = n
while i>0:
    print(str(i), '...' )
    i = i - 1
print('Start!!!')