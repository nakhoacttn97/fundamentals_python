animals = ["dog", "cat", "elephant", "bird", "lion"]
for animal in animals:
    print("animal["+str(animals.index(animal))+"] is "+animal)


