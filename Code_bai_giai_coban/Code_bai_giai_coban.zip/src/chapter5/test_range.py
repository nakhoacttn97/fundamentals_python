
# print('Dạng 1:', list(range(10))) # start=0, stop=10, step=1
# print()

# print('Dạng 2:', list(range(1, 10))) # start=1, stop=10, step=1
# print()

# print('Dạng 3:', list(range(0, 10, 2))) # start=0, stop=10, step=2

for i in range(0, 10, 2):
    print(i, end=', ')
