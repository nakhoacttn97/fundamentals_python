# Học viên: Nguyễn Anh Khoa - LDS1_281T37
# Câu 5:

s = '''
Hôm nay công ty có 5 khách hàng mới. Thông tin của khách hàng như sau:
Khách hàng 1: Nguyễn Trọng Duy. SDT: 097,797,23868.
Khách hàng 2: Lê Trọng     Đạt. SDT: 093,210,9990.
Khách hàng 3: Nguyễn  Tấn    Ngọc  Tâm. SDT: 090,930.8018.
Khách hàng 4: Nguyễn    Minh  Khôi. SDT: 091,3xx,6895.
Khách hàng 5: Nguyễn   Thị   Thanh   Nhạn. SDT: 135.504.2483.
'''

# Chưa xong !!!
